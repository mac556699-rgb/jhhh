package com.ralseikeyboard;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(30,30,30,30);
        TextView t = new TextView(this);
        t.setText("💚 Ralsei Keyboard\n\n1. Включи клавиатуру в настройках.\n2. Выбери Ralsei Keyboard.\n3. Твой звук будет играть при каждом нажатии.");
        t.setTextSize(18);
        l.addView(t);
        Button settings = new Button(this);
        settings.setText("Открыть настройки клавиатур");
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        l.addView(settings);
        setContentView(l);
    }
}
