package com.ralseikeyboard;

import android.inputmethodservice.InputMethodService;
import android.view.*;
import android.view.inputmethod.InputConnection;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.*;
import java.util.Locale;

public class RalseiKeyboardService extends InputMethodService {
    private LinearLayout root;
    private boolean english = false;
    private boolean symbols = false;
    private boolean caps = false;

    private static final String[][] RU = {
        {"й","ц","у","к","е","н","г","ш","щ","з","х","ъ"},
        {"ф","ы","в","а","п","р","о","л","д","ж","э"},
        {"я","ч","с","м","и","т","ь","б","ю"}
    };
    private static final String[][] EN = {
        {"q","w","e","r","t","y","u","i","o","p"},
        {"a","s","d","f","g","h","j","k","l"},
        {"z","x","c","v","b","n","m"}
    };
    private static final String[][] SYM = {
        {"1","2","3","4","5","6","7","8","9","0"},
        {"@","#","$","_","&","-","+","(",")","/"},
        {"=","<",">","*","\"","'",":",";","!","?"}
    };

    @Override public View onCreateInputView() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(6), dp(5), dp(6), dp(5));
        root.setBackground(makeBg(Color.rgb(3, 10, 13), Color.rgb(7, 20, 17), 0, 0));
        rebuild();
        return root;
    }

    private void rebuild() {
        root.removeAllViews();
        addToolbar();
        String[][] rows = symbols ? SYM : (english ? EN : RU);
        for (String[] row : rows) addRow(row);
        addBottomRow();
    }

    private void addToolbar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(4), dp(1), dp(4), dp(3));

        TextView title = new TextView(this);
        title.setText("♥  RALSEI  ✦");
        title.setTextColor(Color.rgb(115, 242, 173));
        title.setTextSize(13);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(38), 1));

        addToolbarButton(bar, english ? "EN" : "RU", v -> { english = !english; symbols = false; rebuild(); });
        addToolbarButton(bar, symbols ? "АБВ" : "123", v -> { symbols = !symbols; rebuild(); });
        addToolbarButton(bar, "♥", v -> { });
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(43)));
    }

    private void addToolbarButton(LinearLayout bar, String text, View.OnClickListener click) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setGravity(Gravity.CENTER);
        b.setTextColor(Color.rgb(255, 143, 199));
        b.setTextSize(11);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(makeBg(Color.rgb(7, 28, 24), Color.rgb(12, 47, 36), dp(10), dp(1)));
        b.setOnClickListener(click);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(48), dp(34));
        p.setMargins(dp(3), 0, 0, 0);
        bar.addView(b, p);
    }

    private void addRow(String[] row) {
        LinearLayout line = new LinearLayout(this);
        line.setGravity(Gravity.CENTER);
        line.setPadding(0, dp(2), 0, dp(2));
        for (String s : row) addKey(line, caps && !symbols ? s.toUpperCase(Locale.ROOT) : s, false);
        root.addView(line, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private void addBottomRow() {
        LinearLayout line = new LinearLayout(this);
        line.setGravity(Gravity.CENTER);
        line.setPadding(0, dp(2), 0, dp(1));
        addKey(line, symbols ? "АБВ" : "123", true);
        addKey(line, "⇧", true);
        addKey(line, "⌫", true);
        addKey(line, "ПРОБЕЛ", false);
        addKey(line, "↵", true);
        root.addView(line, new LinearLayout.LayoutParams(-1, 0, 1.05f));
    }

    private void addKey(LinearLayout line, String text, boolean special) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setGravity(Gravity.CENTER);
        b.setTextColor(special ? Color.rgb(255, 143, 199) : Color.WHITE);
        b.setTextSize(text.equals("ПРОБЕЛ") ? 11 : (special ? 17 : 17));
        b.setTypeface(Typeface.DEFAULT_BOLD);
        int top = special ? Color.rgb(18, 22, 27) : Color.rgb(7, 31, 24);
        int bottom = special ? Color.rgb(29, 25, 34) : Color.rgb(11, 48, 35);
        b.setBackground(makeBg(top, bottom, dp(9), dp(1)));
        b.setOnClickListener(v -> press(text));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, text.equals("ПРОБЕЛ") ? 2.8f : 1f);
        p.setMargins(dp(2), dp(1), dp(2), dp(1));
        line.addView(b, p);
    }

    private GradientDrawable makeBg(int top, int bottom, float radius, int stroke) {
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{top, bottom});
        bg.setCornerRadius(radius);
        if (stroke > 0) bg.setStroke(dp(stroke), Color.rgb(73, 190, 127));
        return bg;
    }

    private void press(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (s.equals("⌫")) ic.deleteSurroundingText(1, 0);
        else if (s.equals("ПРОБЕЛ")) ic.commitText(" ", 1);
        else if (s.equals("↵")) ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
        else if (s.equals("⇧")) { caps = !caps; rebuild(); }
        else if (s.equals("123")) { symbols = true; rebuild(); }
        else if (s.equals("АБВ")) { symbols = false; rebuild(); }
        else ic.commitText(s, 1);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onDestroy() {
        super.onDestroy();
    }
}
