RALSEI KEYBOARD — RALSEI STYLE v3

Версия без звуков: звук ralsei_key.mp3 удалён, чтобы избежать багов.

Оформление:
- тёмный фон в стиле Deltarune;
- зелёные клавиши с мятной обводкой;
- розовые акценты для специальных кнопок;
- панель RALSEI сверху;
- RU / EN / 123;
- Shift, Backspace, Enter и большой пробел.

Сборка через GitHub Actions:
1. Замените файл app/src/main/java/com/ralseikeyboard/RalseiKeyboardService.java на файл из этого проекта.
2. Удалять старый ralsei_key.mp3 необязательно — он больше не используется.
3. Запустите Actions → Build Ralsei Keyboard → Run workflow.
4. Скачайте новый Artifact с APK.
